import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class ConnectTest {
	public static void main(String[] args) {
		try {
			URL u = new URL("https://ntst.umd.edu");
			u.openStream();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
