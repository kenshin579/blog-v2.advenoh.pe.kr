#!/bin/bash
java -jar portecle.jar
